﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace form3
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         void Renkdegistir()
         {
            Random rnd = new Random();
            int yeniR = rnd.Next(255);
            int yeniG = rnd.Next(255);
            int yeniB = rnd.Next(255);
            label1.ForeColor = Color.FromArgb(yeniR, yeniG, yeniB);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Font = new Font(label1.Font.FontFamily, label1.Font.Size+1);
            Renkdegistir();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label1.Font = new Font(label1.Font.FontFamily, label1.Font.Size-1);
            Renkdegistir();
        }
    }
}
